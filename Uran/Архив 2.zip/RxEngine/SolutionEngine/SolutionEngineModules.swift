import Foundation

private enum ModuleHelpers {
    static func normalizeName(_ value: String) -> String {
        SolutionReferenceStore.normalizeToken(value)
    }

    static func regexMatches(_ text: String, pattern: String, options: NSRegularExpression.Options = []) -> [NSTextCheckingResult] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: options) else {
            return []
        }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        return regex.matches(in: text, options: [], range: range)
    }

    static func firstCapture(_ text: String, pattern: String, group: Int = 1, options: NSRegularExpression.Options = []) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: options) else {
            return nil
        }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        guard let match = regex.firstMatch(in: text, options: [], range: range),
              let captureRange = Range(match.range(at: group), in: text)
        else {
            return nil
        }
        return String(text[captureRange])
    }

    static func parseNumber(_ value: String?) -> Double? {
        guard let value else { return nil }
        let trimmed = value.replacingOccurrences(of: ",", with: ".")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return Double(trimmed)
    }

    static func parseUnit(_ value: String?) -> String? {
        guard let value else { return nil }
        let unit = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return unit.isEmpty ? nil : unit
    }

    static func canonicalDisplayName(from ingredient: SolutionResolvedIngredient) -> String {
        if let canonical = ingredient.canonicalName, !canonical.isEmpty {
            return canonical
        }
        return ingredient.base.name
    }

    static func uniqueOrdered(_ values: [String]) -> [String] {
        var seen: Set<String> = []
        var output: [String] = []
        for value in values where !value.isEmpty {
            if seen.insert(value).inserted {
                output.append(value)
            }
        }
        return output
    }
}

struct IngredientParser {
    func parse(request: SolutionEngineRequest, references: SolutionReferenceStore) -> SolutionParsedInput {
        if let structured = request.structuredInput {
            return parseStructured(request: request, structured: structured)
        }
        return parseText(request: request, references: references)
    }

    private func parseStructured(request: SolutionEngineRequest, structured: StructuredSolutionInput) -> SolutionParsedInput {
        let ingredients = structured.ingredients.map { value in
            SolutionParsedIngredient(
                id: UUID(),
                rawLine: value.name,
                name: value.name,
                normalizedName: ModuleHelpers.normalizeName(value.name),
                presentationKind: value.presentationKind,
                massG: value.massG,
                volumeMl: value.volumeMl,
                concentrationPercent: value.concentrationPercent,
                ratioDenominator: ModuleHelpers.parseNumber(ModuleHelpers.firstCapture(value.ratio ?? "", pattern: #"\d+\s*[:/]\s*(\d+)"#)),
                isAd: value.isAd ?? false,
                adTargetMl: value.adTargetMl,
                isTargetSolutionLine: false
            )
        }

        return SolutionParsedInput(
            dosageForm: structured.dosageForm ?? "solution",
            routeHint: structured.route ?? request.route,
            signa: structured.signa ?? "",
            targetVolumeMl: structured.targetVolumeMl,
            ingredients: ingredients,
            parserWarnings: []
        )
    }

    private func parseText(request: SolutionEngineRequest, references: SolutionReferenceStore) -> SolutionParsedInput {
        let original = request.recipeText ?? ""
        let normalized = applyRegexNormalization(text: original, patterns: references.regexPatterns)

        let signa = extractSigna(from: normalized)
        let body = stripSigna(from: normalized)
        let lines = body
            .components(separatedBy: CharacterSet.newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }

        var ingredients: [SolutionParsedIngredient] = []
        var warnings: [SolutionWarning] = []
        var targetVolumeMl: Double? = nil

        for raw in lines {
            var candidateLine = raw
            candidateLine = candidateLine.replacingOccurrences(
                of: #"^\s*(rp\.?|recipe)\s*:?\s*"#,
                with: "",
                options: [.regularExpression, .caseInsensitive]
            )
            let lowered = candidateLine.lowercased()
            if lowered.isEmpty {
                continue
            }
            if lowered.hasPrefix("m.d.s") || lowered.hasPrefix("d.s") || lowered.hasPrefix("signa") {
                continue
            }

            if let ingredient = parseIngredientLine(candidateLine) {
                ingredients.append(ingredient)
                if targetVolumeMl == nil,
                   ingredient.isTargetSolutionLine,
                   let volume = ingredient.volumeMl,
                   volume > 0 {
                    targetVolumeMl = volume
                }
                if ingredient.isAd, let adTarget = ingredient.adTargetMl, adTarget > 0 {
                    targetVolumeMl = adTarget
                }
            } else {
                warnings.append(
                    SolutionWarning(
                        code: "ingredient_parse_partial",
                        severity: .warning,
                        message: "Ingredient line could not be fully parsed: \(raw)",
                        state: .inputParsed
                    )
                )
            }
        }

        if ingredients.isEmpty {
            warnings.append(
                SolutionWarning(
                    code: "no_usable_ingredients",
                    severity: .critical,
                    message: "No parsable ingredients found in input",
                    state: .inputParsed
                )
            )
        }

        let routeHint = request.route ?? detectRouteHint(signa: signa, references: references)

        return SolutionParsedInput(
            dosageForm: "solution",
            routeHint: routeHint,
            signa: signa,
            targetVolumeMl: targetVolumeMl,
            ingredients: ingredients,
            parserWarnings: warnings
        )
    }

    private func applyRegexNormalization(text: String, patterns: [RegexNormalizationPattern]) -> String {
        var output = text
        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern.pattern, options: regexOptions(pattern.flags)) else {
                continue
            }
            let range = NSRange(output.startIndex..<output.endIndex, in: output)
            output = regex.stringByReplacingMatches(in: output, options: [], range: range, withTemplate: pattern.replacement)
        }
        return output
    }

    private func regexOptions(_ flags: String) -> NSRegularExpression.Options {
        var options: NSRegularExpression.Options = []
        if flags.contains("i") {
            options.insert(.caseInsensitive)
        }
        return options
    }

    private func extractSigna(from text: String) -> String {
        let patterns = [
            #"(?is)(?:m\.?\s*d\.?\s*s\.?|d\.?\s*s\.?|signa\.?|s\.)\s*[:\-]?\s*(.+)$"#
        ]
        for pattern in patterns {
            if let capture = ModuleHelpers.firstCapture(text, pattern: pattern, group: 1, options: [.caseInsensitive]) {
                return capture.trimmingCharacters(in: .whitespacesAndNewlines)
            }
        }
        return ""
    }

    private func stripSigna(from text: String) -> String {
        let pattern = #"(?is)^(.+?)(?:m\.?\s*d\.?\s*s\.?|d\.?\s*s\.?|signa\.?|s\.)\s*[:\-]?.*$"#
        if let capture = ModuleHelpers.firstCapture(text, pattern: pattern, group: 1, options: [.caseInsensitive]) {
            return capture
        }
        return text
    }

    private func parseIngredientLine(_ raw: String) -> SolutionParsedIngredient? {
        let cleaned = raw
            .replacingOccurrences(of: "—", with: "-")
            .replacingOccurrences(of: "–", with: "-")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return nil }

        let isAd = cleaned.range(of: #"\b(ad|q\.s\.?)\b"#, options: [.regularExpression, .caseInsensitive]) != nil

        let amountMatches = ModuleHelpers.regexMatches(cleaned, pattern: #"(\d+(?:\.\d+)?)\s*(ml|mL|мл|g|gr|г|гр)\b"#, options: [.caseInsensitive])
        var massG: Double?
        var volumeMl: Double?
        if let last = amountMatches.last,
           let valueRange = Range(last.range(at: 1), in: cleaned),
           let unitRange = Range(last.range(at: 2), in: cleaned) {
            let numeric = ModuleHelpers.parseNumber(String(cleaned[valueRange]))
            let unit = ModuleHelpers.parseUnit(String(cleaned[unitRange]))
            if unit == "g" || unit == "gr" || unit == "г" || unit == "гр" {
                massG = numeric
            } else {
                volumeMl = numeric
            }
        } else if let bareValue = ModuleHelpers.parseNumber(
            ModuleHelpers.firstCapture(cleaned, pattern: #"(\d+(?:\.\d+)?)\s*$"#, group: 1, options: [.caseInsensitive])
        ) {
            // In many latin prescriptions unit is omitted for solids; default to grams.
            massG = bareValue
        }

        let concentrationPercent = ModuleHelpers.parseNumber(
            ModuleHelpers.firstCapture(cleaned, pattern: #"(\d+(?:\.\d+)?)\s*%"#, group: 1, options: [.caseInsensitive])
        )
        let ratioDenominator = ModuleHelpers.parseNumber(
            ModuleHelpers.firstCapture(cleaned, pattern: #"\d+\s*[:/]\s*(\d+)"#, group: 1, options: [.caseInsensitive])
        )

        let adTargetMl = ModuleHelpers.parseNumber(
            ModuleHelpers.firstCapture(cleaned, pattern: #"(?:ad|q\.s\.?)\s*(\d+(?:\.\d+)?)\s*(?:ml|мл)?"#, group: 1, options: [.caseInsensitive])
        )

        let baseName = deriveIngredientName(cleaned)
        let presentation = detectPresentationKind(cleaned)
        let targetLine = isTargetSolutionLine(name: baseName, cleaned: cleaned, presentationKind: presentation, concentrationPercent: concentrationPercent, volumeMl: volumeMl)

        return SolutionParsedIngredient(
            id: UUID(),
            rawLine: raw,
            name: baseName,
            normalizedName: ModuleHelpers.normalizeName(baseName),
            presentationKind: presentation,
            massG: massG,
            volumeMl: volumeMl,
            concentrationPercent: concentrationPercent,
            ratioDenominator: ratioDenominator,
            isAd: isAd,
            adTargetMl: adTargetMl,
            isTargetSolutionLine: targetLine
        )
    }

    private func deriveIngredientName(_ line: String) -> String {
        let lower = line.lowercased()
        if lower.contains("aquae purificatae") || lower.contains("aq. purif") {
            return "Aqua purificata"
        }
        if lower.contains("aquae menthae") {
            return "Aqua Menthae"
        }
        if lower.contains("sirupi simplicis") {
            return "Sirupus simplex"
        }
        if lower.contains("extracti crataegi fluidi") {
            return "Extractum Crataegi fluidum"
        }
        if lower.contains("extracti belladonnae sicci") {
            return "Extractum Belladonnae siccum"
        }
        if lower.contains("extracti belladonnae fluidi") {
            return "Extractum Belladonnae fluidum"
        }
        if lower.contains("hydrogenii peroxydi diluta") {
            return "Solutio Hydrogenii peroxydi diluta"
        }
        if lower.contains("furacilini 1:5000") {
            return "Sol. Furacilini 1:5000"
        }
        if lower.contains("spiritus aethylici") || lower.contains("spiritus ethylici") {
            return "Ethanol 70%"
        }

        let hasSolutionPrefix = lower.contains("sol.") || lower.contains("solut")
        let hasDash = line.contains("-")
        if hasSolutionPrefix && !hasDash {
            var full = line
            full = full.replacingOccurrences(of: #"(\d+(?:\.\d+)?)\s*(ml|mL|мл|g|gr|г|гр)\b\s*$"#, with: "", options: [.regularExpression, .caseInsensitive])
            return full.trimmingCharacters(in: CharacterSet(charactersIn: " .,:;\t\n\r"))
        }

        var name = line
        name = name.replacingOccurrences(of: #"(?:^|\s)(\d+(?:\.\d+)?)\s*(ml|mL|мл|g|gr|г|гр)\b"#, with: "", options: [.regularExpression, .caseInsensitive])
        name = name.replacingOccurrences(of: #"\b(\d+(?:\.\d+)?)\s*$"#, with: "", options: [.regularExpression, .caseInsensitive])
        name = name.replacingOccurrences(of: #"\b(ad|q\.s\.?)\b\s*(\d+(?:\.\d+)?)?\s*(ml|мл)?"#, with: "", options: [.regularExpression, .caseInsensitive])
        name = name.replacingOccurrences(of: #"\b\d+(?:\.\d+)?\s*%"#, with: "", options: [.regularExpression])
        name = name.replacingOccurrences(of: #"\b\d+\s*[:/]\s*\d+\b"#, with: "", options: [.regularExpression])
        name = name.replacingOccurrences(of: "-", with: " ")
        name = name.replacingOccurrences(of: "  +", with: " ", options: .regularExpression)
        name = name.trimmingCharacters(in: CharacterSet(charactersIn: " .,:;\t\n\r"))

        if name.lowercased().hasPrefix("sol ") {
            name = String(name.dropFirst(4)).trimmingCharacters(in: .whitespacesAndNewlines)
        }
        if name.lowercased().hasPrefix("sol.") {
            name = String(name.dropFirst(4)).trimmingCharacters(in: .whitespacesAndNewlines)
        }

        return name
    }

    private func detectPresentationKind(_ line: String) -> String? {
        let lower = line.lowercased()
        if lower.contains("t-ra") || lower.contains("tinct") {
            return "tincture"
        }
        if lower.contains("sirup") {
            return "syrup"
        }
        if lower.contains("extract") && (lower.contains("fluid") || lower.contains("fl.") || lower.contains("liquid")) {
            return "liquid_extract"
        }
        if lower.contains("extract") && (lower.contains("sicc") || lower.contains("dry")) {
            return "dry_extract"
        }
        if lower.contains("sol.") || lower.contains("solut") {
            return "solution"
        }
        if lower.contains("spirit") || lower.contains("ethanol") {
            return "alcohol"
        }
        if lower.contains("aether") || lower.contains("chloroform") {
            return "volatile_solvent"
        }
        if lower.contains("oleum") || lower.contains("oil") {
            return "oil"
        }
        if lower.contains("glycerin") || lower.contains("glycerol") {
            return "glycerin"
        }
        if lower.contains("aqua") {
            return "aqueous"
        }
        return nil
    }

    private func isTargetSolutionLine(
        name: String,
        cleaned: String,
        presentationKind: String?,
        concentrationPercent: Double?,
        volumeMl: Double?
    ) -> Bool {
        guard let concentrationPercent, concentrationPercent > 0,
              let volumeMl, volumeMl > 0 else {
            return false
        }
        guard presentationKind == "solution" else { return false }
        let low = cleaned.lowercased()
        return low.contains("sol") && (low.contains("-") || low.contains(" - ")) && !name.isEmpty
    }

    private func detectRouteHint(signa: String, references: SolutionReferenceStore) -> String? {
        let signaToken = ModuleHelpers.normalizeName(signa)
        guard !signaToken.isEmpty else { return nil }

        for (route, aliases) in references.normalizationDictionary.routeHints {
            for alias in aliases {
                if signaToken.contains(ModuleHelpers.normalizeName(alias)) {
                    return route
                }
            }
        }
        return nil
    }
}

struct SubstanceResolver {
    func resolve(ingredients: [SolutionNormalizedIngredient], references: SolutionReferenceStore) -> (resolved: [SolutionResolvedIngredient], warnings: [SolutionWarning], unresolvedRuleExists: Bool) {
        var resolved: [SolutionResolvedIngredient] = []
        var warnings: [SolutionWarning] = []
        var unresolvedRuleExists = false

        for ingredient in ingredients {
            let substanceKey = ingredient.substanceKey ?? references.resolveSubstanceKey(for: ingredient.normalizedName)
            let keyToken = substanceKey.map(SolutionReferenceStore.normalizeToken)
            let master = keyToken.flatMap { references.substanceMasterByKey[$0] }
            let canonicalName = references.resolveSpecCanonicalName(for: ingredient.normalizedName, substanceKey: substanceKey)
                ?? master?.name.latNom
                ?? master?.name.latGen
            let safety = keyToken.flatMap { references.safetyByKey[$0] }
            let dose = keyToken.flatMap { references.doseLimitsByKey[$0] }
            let physchem = keyToken.flatMap { references.physchemByKey[$0] }
            let solutionRef = keyToken.flatMap { references.solutionReferenceByKey[$0] }

            var updated = ingredient
            updated.substanceKey = substanceKey

            if substanceKey == nil {
                warnings.append(
                    SolutionWarning(
                        code: "unresolved_substance",
                        severity: .warning,
                        message: "Ingredient unresolved in alias table: \(ingredient.name)",
                        state: .substancesResolved
                    )
                )
                unresolvedRuleExists = true
            }

            resolved.append(
                SolutionResolvedIngredient(
                    base: updated,
                    substanceKey: substanceKey,
                    canonicalName: canonicalName,
                    safety: safety,
                    doseLimit: dose,
                    physchem: physchem,
                    solutionReference: solutionRef
                )
            )
        }

        return (resolved, warnings, unresolvedRuleExists)
    }
}

struct BehaviorProfileResolver {
    func resolve(resolved: [SolutionResolvedIngredient], references: SolutionReferenceStore) -> (items: [SolutionBehaviorIngredient], warnings: [SolutionWarning], missingBehaviorProfile: Bool, unresolvedRuleExists: Bool) {
        var items: [SolutionBehaviorIngredient] = []
        var warnings: [SolutionWarning] = []
        var missingBehaviorProfile = false
        var unresolvedRuleExists = false

        for ingredient in resolved {
            let lookupName = ingredient.canonicalName ?? ingredient.base.normalizedName
            var behavior = references.resolveBehavior(for: lookupName, substanceKey: ingredient.substanceKey)
            let solubility = references.resolveSolubility(for: lookupName, substanceKey: ingredient.substanceKey)
            let specialCase = references.resolveSpecialCase(for: lookupName, substanceKey: ingredient.substanceKey)
            let concentrate = references.resolveConcentrate(for: lookupName, substanceKey: ingredient.substanceKey)
            let packaging = references.resolvePackaging(for: lookupName, substanceKey: ingredient.substanceKey)

            if behavior == nil, let solubility {
                // Deterministic fallback from solubility table, not a guessed behavior.
                behavior = IngredientBehaviorRecord(
                    key: ingredient.canonicalName ?? ingredient.base.name,
                    aliases: [ingredient.base.name],
                    behaviorType: "drySubstance",
                    introductionMode: "direct_dissolve",
                    countsAsLiquid: false,
                    countsAsSolid: true,
                    affectsAd: false,
                    affectsKvo: true,
                    solubilityClass: solubility.solubilityInWater,
                    phaseType: "unknown",
                    requiresSeparateDissolution: solubility.requiresSeparateDissolution,
                    requiredPreDissolutionSolvent: solubility.recommendedPreDissolutionSolvent,
                    addAtEnd: false,
                    orderPriority: 300,
                    heatPolicy: solubility.heatingAllowed ? "allow_heating" : "no_heating",
                    volatilityPolicy: "none",
                    filtrationPolicy: "normal_if_needed",
                    lightSensitive: false,
                    sterilitySensitive: false,
                    routeRestrictions: [],
                    compatibilityHints: solubility.notes
                )
            }

            if behavior == nil {
                warnings.append(
                    SolutionWarning(
                        code: "missing_behavior_profile",
                        severity: .warning,
                        message: "Behavior profile missing for \(ingredient.base.name)",
                        state: .behaviorProfilesAttached
                    )
                )
                missingBehaviorProfile = true
                unresolvedRuleExists = true
            }

            let presentation = ingredient.base.presentationKind?.lowercased() ?? ""
            let nameSuggestsSolution = ingredient.base.normalizedName.contains("sol ")
                || ingredient.base.normalizedName.contains("solutio")
                || ingredient.base.normalizedName.contains("liquor")
            if presentation == "solution",
               behavior?.countsAsSolid == true,
               !ingredient.base.isTargetSolutionLine {
                warnings.append(
                    SolutionWarning(
                        code: "ingredient_form_conflict",
                        severity: .warning,
                        message: "Ingredient metadata conflicts with solution presentation: \(ingredient.base.name)",
                        state: .behaviorProfilesAttached
                    )
                )
            }
            if (presentation == "solid" || presentation == "substance") && nameSuggestsSolution {
                warnings.append(
                    SolutionWarning(
                        code: "ingredient_form_conflict",
                        severity: .warning,
                        message: "Ingredient name suggests solution object but input marks it as solid",
                        state: .behaviorProfilesAttached
                    )
                )
            }

            items.append(
                SolutionBehaviorIngredient(
                    resolved: ingredient,
                    behavior: behavior,
                    solubility: solubility,
                    specialCase: specialCase,
                    concentrate: concentrate,
                    packaging: packaging
                )
            )
        }

        return (items, warnings, missingBehaviorProfile, unresolvedRuleExists)
    }
}

struct SolutionBranchSelector {
    func resolveRoute(
        parsedInput: SolutionParsedInput,
        request: SolutionEngineRequest,
        references: SolutionReferenceStore
    ) -> (resolution: SolutionRouteResolution, warnings: [SolutionWarning]) {
        var warnings: [SolutionWarning] = []

        let explicitRoute = request.route
            ?? request.structuredInput?.route
            ?? parsedInput.routeHint

        if let explicitRoute,
           let routePolicy = references.resolveRoutePolicy(for: explicitRoute) {
            return (
                SolutionRouteResolution(route: routePolicy.routeKey, policy: routePolicy, usedFallback: false),
                warnings
            )
        }

        let signaToken = SolutionReferenceStore.normalizeToken(parsedInput.signa)
        for (routeKey, aliases) in references.normalizationDictionary.routeHints {
            for alias in aliases {
                if signaToken.contains(SolutionReferenceStore.normalizeToken(alias)),
                   let policy = references.resolveRoutePolicy(for: routeKey) {
                    return (
                        SolutionRouteResolution(route: policy.routeKey, policy: policy, usedFallback: false),
                        warnings
                    )
                }
            }
        }

        let fallback = references.routeByKey[SolutionReferenceStore.normalizeToken("oral")]
        warnings.append(
            SolutionWarning(
                code: "route_fallback_used",
                severity: .warning,
                message: "Route inferred by fallback policy",
                state: .routeResolved
            )
        )

        return (
            SolutionRouteResolution(route: fallback?.routeKey ?? "oral", policy: fallback, usedFallback: true),
            warnings
        )
    }

    func selectBranch(
        items: [SolutionBehaviorIngredient],
        route: SolutionRouteResolution,
        request: SolutionEngineRequest,
        references: SolutionReferenceStore
    ) -> (resolution: SolutionBranchResolution, warnings: [SolutionWarning], blocked: Bool, routeConflict: Bool) {
        var warnings: [SolutionWarning] = []
        var blocked = false
        var routeConflict = false

        let nonAdItems = items.filter { !$0.resolved.base.isAd }

        let hasVolatileSolvent = nonAdItems.contains {
            ($0.behavior?.behaviorType == "volatileSolvent")
                || ($0.resolved.base.presentationKind == "volatile_solvent")
        }
        let hasNonAqueousSolvent = nonAdItems.contains {
            guard let behaviorType = $0.behavior?.behaviorType else {
                return ["alcohol", "glycerin", "oil", "volatile_solvent"].contains(($0.resolved.base.presentationKind ?? "").lowercased())
            }
            return ["alcohol", "glycerin", "oil", "mixedLiquid", "volatileSolvent"].contains(behaviorType)
        }
        let hasReadySolution = nonAdItems.contains { $0.behavior?.behaviorType == "readySolution" }
        let hasStandardSolution = nonAdItems.contains { $0.behavior?.behaviorType == "standardSolution" }
        let hasDrySolids = nonAdItems.contains {
            if let behavior = $0.behavior {
                return behavior.countsAsSolid
            }
            return ($0.resolved.base.massG ?? 0) > 0
        }

        let hasTargetSolutionLine = nonAdItems.contains(where: { $0.resolved.base.isTargetSolutionLine })
        let forceConcentrates = request.forceReferenceConcentrate ?? [:]

        let concentrateCapableSolids = nonAdItems.filter {
            let isSolid = $0.behavior?.countsAsSolid ?? (($0.resolved.base.massG ?? 0) > 0)
            guard isSolid else { return false }
            return $0.concentrate?.hasStandardConcentrate == true
        }

        let hasIodum = nonAdItems.contains {
            let specKey = references.resolveSpecSubstanceKey(
                for: $0.resolved.base.normalizedName,
                substanceKey: $0.resolved.substanceKey
            )
            let token = SolutionReferenceStore.normalizeToken(specKey ?? $0.resolved.substanceKey ?? $0.resolved.base.name)
            return token == "iodum" || token == "iodi" || token.contains("iodum")
        }
        let hasKaliiIodidi = nonAdItems.contains {
            let specKey = references.resolveSpecSubstanceKey(
                for: $0.resolved.base.normalizedName,
                substanceKey: $0.resolved.substanceKey
            )
            let token = SolutionReferenceStore.normalizeToken(specKey ?? $0.resolved.substanceKey ?? $0.resolved.base.name)
            return token.contains("kalii iodid")
        }

        let hasMenthol = nonAdItems.contains {
            let specKey = references.resolveSpecSubstanceKey(
                for: $0.resolved.base.normalizedName,
                substanceKey: $0.resolved.substanceKey
            )
            let token = SolutionReferenceStore.normalizeToken(specKey ?? $0.resolved.substanceKey ?? $0.resolved.base.name)
            return token == "mentholum" || token == "mentholi" || token.contains("menthol")
        }
        let hasCamphor = nonAdItems.contains {
            let specKey = references.resolveSpecSubstanceKey(
                for: $0.resolved.base.normalizedName,
                substanceKey: $0.resolved.substanceKey
            )
            let token = SolutionReferenceStore.normalizeToken(specKey ?? $0.resolved.substanceKey ?? $0.resolved.base.name)
            return token == "camphora" || token == "camphorae" || token.contains("camphor")
        }

        let hasSpecialCase = nonAdItems.contains { $0.specialCase != nil }

        var branch = "aqueous_true_solution"
        var classification = "aqueous_solution"

        if hasVolatileSolvent {
            branch = "volatile_non_aqueous_solution"
            classification = "non_aqueous_solution"
        } else if hasNonAqueousSolvent {
            branch = "non_aqueous_solution"
            classification = "non_aqueous_solution"
        } else if hasIodum && hasKaliiIodidi {
            branch = "special_dissolution_path"
            classification = "special_solution"
        } else if hasSpecialCase,
                  nonAdItems.contains(where: { ["Protargolum", "Collargolum"].contains($0.specialCase?.caseKey ?? "") }) {
            branch = "special_dissolution_path"
            classification = "special_solution"
        } else if hasReadySolution && !hasDrySolids {
            branch = "ready_solution_mix"
            classification = "aqueous_solution"
        } else if hasStandardSolution && !hasDrySolids {
            branch = "standard_solution_mix"
            classification = "aqueous_solution"
        } else if !forceConcentrates.isEmpty || hasTargetSolutionLine || concentrateCapableSolids.count >= 2 {
            branch = "aqueous_burette_solution"
            classification = "aqueous_solution"
        }

        if hasMenthol && hasCamphor && hasNonAqueousSolvent {
            branch = "non_aqueous_solution"
            classification = "non_aqueous_solution"
        }

        if hasIodum,
           branch == "aqueous_true_solution" {
            branch = "special_dissolution_path"
            classification = "special_solution"
        }

        let missingCoSolvent = nonAdItems.contains {
            guard let solubility = $0.solubility else { return false }
            if !solubility.requiresCoSolvent {
                return false
            }
            return !hasNonAqueousSolvent
        }

        if missingCoSolvent {
            warnings.append(
                SolutionWarning(
                    code: "co_solvent_required_but_missing",
                    severity: .critical,
                    message: "Co-solvent required by solubility rules but missing",
                    state: .solutionBranchSelected
                )
            )
            warnings.append(
                SolutionWarning(
                    code: "blocked_aqueous_true_solution_used",
                    severity: .critical,
                    message: "Blocked aqueous true-solution route attempted for co-solvent case",
                    state: .solutionBranchSelected
                )
            )
            if branch == "aqueous_true_solution" || branch == "ready_solution_mix" || branch == "standard_solution_mix" {
                blocked = true
            }
        }

        if let policy = route.policy {
            let allowed = policy.allowedSolutionBranches
            if !isBranchAllowed(branch: branch, allowedBranches: allowed) {
                if ["injection", "inhalation", "ophthalmic"].contains(route.route) {
                    warnings.append(
                        SolutionWarning(
                            code: "branch_not_allowed_for_route",
                            severity: .critical,
                            message: "Selected branch \(branch) is not allowed for route \(route.route)",
                            state: .solutionBranchSelected
                        )
                    )
                    blocked = true
                } else {
                    routeConflict = true
                    warnings.append(
                        SolutionWarning(
                            code: "route_policy_conflict",
                            severity: .warning,
                            message: "Route policy has unresolved restrictions for branch \(branch)",
                            state: .solutionBranchSelected
                        )
                    )
                }
            }

            if policy.requiresSterility {
                warnings.append(
                    SolutionWarning(
                        code: "sterility_required_but_not_supported",
                        severity: .critical,
                        message: "Sterile route requires dedicated sterile module",
                        state: .solutionBranchSelected
                    )
                )
                if route.route == "injection" || route.route == "ophthalmic" {
                    blocked = true
                }
            }
            if policy.requiresIsotonicityCheck {
                warnings.append(
                    SolutionWarning(
                        code: "isotonicity_required_but_not_checked",
                        severity: .warning,
                        message: "Route requires isotonicity check which is not available in this module",
                        state: .solutionBranchSelected
                    )
                )
            }
            if policy.requiresPHCheck {
                warnings.append(
                    SolutionWarning(
                        code: "ph_check_required_but_missing",
                        severity: .warning,
                        message: "Route requires pH check which is not available in this module",
                        state: .solutionBranchSelected
                    )
                )
            }
        }

        for override in references.manualOverrides {
            if let routeMatch = override.match.route,
               SolutionReferenceStore.normalizeToken(routeMatch) == SolutionReferenceStore.normalizeToken(route.route) {
                if let forced = override.action.forceConfidence,
                   forced == "blocked" {
                    blocked = true
                }
                for code in override.action.addWarnings ?? [] {
                    warnings.append(
                        SolutionWarning(
                            code: code,
                            severity: .critical,
                            message: "Manual override: \(code)",
                            state: .solutionBranchSelected
                        )
                    )
                }
            }
            if let keys = override.match.substanceKeys,
               keys.contains(where: { key in
                   nonAdItems.contains { SolutionReferenceStore.normalizeToken($0.resolved.substanceKey ?? "") == SolutionReferenceStore.normalizeToken(key) }
               }) {
                if let forceBranch = override.action.forceBranch {
                    branch = forceBranch == "special_dissolution_path" ? "special_dissolution_path" : forceBranch
                    classification = "special_solution"
                }
            }
        }

        return (
            SolutionBranchResolution(classification: classification, branch: branch),
            warnings,
            blocked,
            routeConflict
        )
    }

    func runPreCalculationChecks(
        parsedInput: SolutionParsedInput,
        items: [SolutionBehaviorIngredient],
        branch: SolutionBranchResolution
    ) -> (targetVolumeMl: Double?, warnings: [SolutionWarning], blocked: Bool, fallbackTargetUsed: Bool) {
        var warnings: [SolutionWarning] = []
        var blocked = false
        var fallbackTargetUsed = false

        let adItems = items.filter { $0.resolved.base.isAd }
        if adItems.count > 1 {
            warnings.append(
                SolutionWarning(
                    code: "multiple_ad_conflict",
                    severity: .critical,
                    message: "Multiple ad/q.s markers detected",
                    state: .preCalcChecksDone
                )
            )
            blocked = true
        }

        let fixedPurifiedWater = items.contains {
            !$0.resolved.base.isAd
                && ($0.behavior?.behaviorType == "purifiedWater")
                && (($0.resolved.base.volumeMl ?? 0) > 0)
        }
        let hasWaterAd = items.contains {
            $0.resolved.base.isAd && ($0.behavior?.behaviorType == "purifiedWater" || $0.resolved.base.normalizedName.contains("aqua purificata"))
        }
        if fixedPurifiedWater && hasWaterAd {
            warnings.append(
                SolutionWarning(
                    code: "fixed_water_vs_ad_conflict",
                    severity: .critical,
                    message: "Fixed purified water and water ad marker conflict",
                    state: .preCalcChecksDone
                )
            )
            blocked = true
        }

        let hasWaterPhase = items.contains {
            let behavior = $0.behavior?.behaviorType ?? ""
            return behavior == "purifiedWater"
                || behavior == "aqueousSolvent"
                || $0.resolved.base.normalizedName.contains("aqua")
                || ($0.resolved.base.isAd && $0.resolved.base.normalizedName.contains("aqua"))
        }
        let hasOilPhase = items.contains { $0.behavior?.behaviorType == "oil" }
        if hasWaterPhase && hasOilPhase {
            warnings.append(
                SolutionWarning(
                    code: "incompatible_solvent_phases",
                    severity: .critical,
                    message: "Water and oil phases conflict for true solution path",
                    state: .preCalcChecksDone
                )
            )
            blocked = true
        }

        let targetRequired = parsedInput.targetVolumeMl != nil || !adItems.isEmpty
        var target = parsedInput.targetVolumeMl
            ?? adItems.compactMap { $0.resolved.base.adTargetMl }.first

        if target == nil, targetRequired {
            let fixedLiquids = items
                .filter { !$0.resolved.base.isAd }
                .compactMap { $0.resolved.base.volumeMl }
                .filter { $0 > 0 }
            if fixedLiquids.count == 1, let only = fixedLiquids.first {
                target = only
            }
        }

        if target == nil, targetRequired {
            let candidateVolumes = items
                .filter { !$0.resolved.base.isAd }
                .compactMap { $0.resolved.base.volumeMl }
                .filter { $0 > 0 }
            if let fallback = candidateVolumes.max() {
                target = fallback
                fallbackTargetUsed = true
                warnings.append(
                    SolutionWarning(
                        code: "target_inferred_by_fallback",
                        severity: .warning,
                        message: "Target volume inferred by fallback largest-liquid rule",
                        state: .preCalcChecksDone
                    )
                )
            }
        }

        if target == nil, targetRequired {
            warnings.append(
                SolutionWarning(
                    code: "target_volume_missing",
                    severity: .critical,
                    message: "Target volume is required for ad calculation",
                    state: .preCalcChecksDone
                )
            )
            blocked = true
        }

        return (target, warnings, blocked, fallbackTargetUsed)
    }

    private func isBranchAllowed(branch: String, allowedBranches: [String]) -> Bool {
        let branchToken = SolutionReferenceStore.normalizeToken(branch)
        for allowed in allowedBranches {
            let token = SolutionReferenceStore.normalizeToken(allowed)
            if token == branchToken {
                return true
            }
            if branch == "aqueous_true_solution" && token.contains("aqueous_true_solution") {
                return true
            }
            if branch == "aqueous_burette_solution" && token == "burette_concentrate_path" {
                return true
            }
            if branch == "ready_solution_mix" && ["standard_solution_mix", "aqueous_true_solution"].contains(token) {
                return true
            }
            if branch == "standard_solution_mix" && token == "standard_solution_mix" {
                return true
            }
            if branch == "non_aqueous_solution" && ["alcoholic_solution", "glycerinic_solution", "oily_solution", "volatile_non_aqueous_solution", "non_aqueous_solution"].contains(token) {
                return true
            }
            if branch == "volatile_non_aqueous_solution"
                && ["volatile_non_aqueous_solution", "non_aqueous_solution", "alcoholic_solution", "glycerinic_solution", "oily_solution"].contains(token) {
                return true
            }
            if branch == "special_dissolution_path" && token.contains("special") {
                return true
            }
        }
        return false
    }
}

struct SolutionCalculationEngine {
    func calculate(
        items: [SolutionBehaviorIngredient],
        branch: SolutionBranchResolution,
        targetVolumeMl: Double?,
        forceReferenceConcentrate: [String: String]
    ) -> (trace: SolutionCalculationTrace, warnings: [SolutionWarning], blocked: Bool) {
        var trace = SolutionCalculationTrace()
        trace.targetVolumeMl = targetVolumeMl

        var warnings: [SolutionWarning] = []
        var blocked = false

        var solidKuoInputs: [(mass: Double, kuo: Double?)] = []

        for item in items where !item.resolved.base.isAd {
            let ingredient = item.resolved
            let displayName = ModuleHelpers.canonicalDisplayName(from: ingredient)
            let normalizedDisplay = SolutionReferenceStore.normalizeToken(displayName)

            var mass = ingredient.base.massG
            if ingredient.base.isTargetSolutionLine,
               let concentration = ingredient.base.concentrationPercent,
               let volume = ingredient.base.volumeMl,
               concentration > 0,
               volume > 0 {
                mass = concentration * volume / 100.0
            }

            let hasForcedConcentrate = forceReferenceConcentrate.keys.contains {
                let key = SolutionReferenceStore.normalizeToken($0)
                return key == normalizedDisplay || key == SolutionReferenceStore.normalizeToken(ingredient.base.name)
            }

            let canUseConcentrate = (item.concentrate?.hasStandardConcentrate == true)
                && (branch.branch == "aqueous_burette_solution" || hasForcedConcentrate)

            if canUseConcentrate,
               let mass,
               let decimal = item.concentrate?.concentrationDecimalGPerMl,
               decimal > 0,
               let concentrateName = item.concentrate?.concentrateName {
                let volume = mass / decimal
                trace.requiredMassesG[displayName] = mass.rounded3()
                trace.concentrateVolumesMl[concentrateName] = (trace.concentrateVolumesMl[concentrateName] ?? 0) + volume.rounded3()
                trace.sumCountedLiquidsMl += volume
                trace.lines.append("Concentrate: \(concentrateName) V = \(format(mass)) / \(format(decimal)) = \(format(volume)) ml")
                continue
            }

            let behavior = item.behavior
            let countsAsLiquid = behavior?.countsAsLiquid ?? ((ingredient.base.volumeMl ?? 0) > 0)
            let countsAsSolid = behavior?.countsAsSolid ?? ((ingredient.base.massG ?? 0) > 0)

            if countsAsLiquid {
                let volume = ingredient.base.volumeMl ?? 0
                trace.sumCountedLiquidsMl += volume
                trace.lines.append("Liquid contribution: \(displayName) = \(format(volume)) ml")
            }

            if countsAsSolid, let mass, mass > 0 {
                trace.sumSolidsG += mass
                trace.requiredMassesG[displayName] = mass.rounded3()
                solidKuoInputs.append((mass: mass, kuo: ingredient.physchem?.physchem.kuo ?? ingredient.solutionReference?.solutions.kuo))
            }
        }

        if let target = targetVolumeMl, target > 0 {
            let solidsPercent = trace.sumSolidsG * 100.0 / target
            if branch.branch == "aqueous_true_solution" && solidsPercent >= 3.0 {
                trace.kvoApplied = true
                trace.kvoContributionMl = solidKuoInputs.reduce(0.0) { partial, item in
                    partial + (item.kuo ?? 0) * item.mass
                }
                trace.lines.append("KVO: solids \(format(solidsPercent))% >= 3%, displacement = \(format(trace.kvoContributionMl)) ml")
            }

            if branch.branch == "aqueous_burette_solution" {
                trace.kvoApplied = false
                trace.kvoContributionMl = 0
            }

            let water = target - trace.sumCountedLiquidsMl - (trace.kvoApplied ? trace.kvoContributionMl : 0)
            trace.waterToAddMl = water.rounded3()
            trace.lines.append("Water ad: \(format(target)) - \(format(trace.sumCountedLiquidsMl)) - \(format(trace.kvoContributionMl)) = \(format(water)) ml")

            if water < 0 {
                blocked = true
                warnings.append(
                    SolutionWarning(
                        code: "impossible_formulation",
                        severity: .critical,
                        message: "Counted liquids exceed target volume",
                        state: .coreCalculationsDone
                    )
                )
                warnings.append(
                    SolutionWarning(
                        code: "negative_water_result",
                        severity: .critical,
                        message: "Calculated ad solvent volume is negative",
                        state: .coreCalculationsDone
                    )
                )
            } else if water == 0 {
                warnings.append(
                    SolutionWarning(
                        code: "zero_water_with_unexplained_ad",
                        severity: .warning,
                        message: "Water to add is zero in ad path",
                        state: .coreCalculationsDone
                    )
                )
            }
        }

        trace.sumSolidsG = trace.sumSolidsG.rounded3()
        trace.sumCountedLiquidsMl = trace.sumCountedLiquidsMl.rounded3()
        trace.kvoContributionMl = trace.kvoContributionMl.rounded3()

        return (trace, warnings, blocked)
    }

    private func format(_ value: Double) -> String {
        if value == floor(value) {
            return String(Int(value))
        }
        return String(format: "%.3f", value)
    }
}

struct TechnologyPlanner {
    func plan(
        items: [SolutionBehaviorIngredient],
        branch: SolutionBranchResolution
    ) -> (steps: [String], flags: [String], warnings: [SolutionWarning]) {
        var steps: [String] = []
        var flags: [String] = []
        var warnings: [SolutionWarning] = []

        let specialCases = items.compactMap { $0.specialCase }
        let hasLateAddition = items.contains {
            ($0.behavior?.addAtEnd == true) || ($0.packaging?.prefersAddAtEnd == true) || ($0.behavior?.volatilityPolicy == "add_last")
        }

        for specialCase in specialCases {
            if specialCase.preDissolutionStageRequired {
                flags.append("separate_dissolution_stage")
            }
            if specialCase.orderPolicy == "prepare_combined_subsolution_first" {
                flags.append("prepare_combined_subsolution_first")
            }
            if specialCase.orderPolicy.contains("late") {
                flags.append("late_addition")
            }
            steps.append(contentsOf: specialCase.technologyTemplate)
        }

        if hasLateAddition {
            flags.append("late_addition")
        }

        let disallowHeatingByBranch = branch.branch == "non_aqueous_solution" || branch.branch == "volatile_non_aqueous_solution"

        if branch.branch == "volatile_non_aqueous_solution" {
            flags.append("no_heating")
            flags.append("late_addition")
        }

        if branch.branch == "non_aqueous_solution" {
            let hasMenthol = items.contains { SolutionReferenceStore.normalizeToken($0.resolved.base.name).contains("menthol") }
            let hasCamphor = items.contains { SolutionReferenceStore.normalizeToken($0.resolved.base.name).contains("camphor") }
            if hasMenthol && hasCamphor {
                flags.append("prepare_combined_subsolution_first")
            }
        }

        let shouldHeat = items.contains {
            ($0.solubility?.heatingHelpful == true)
                && ($0.solubility?.heatingAllowed == true)
                && ($0.behavior?.heatPolicy != "no_heating")
        }
        if shouldHeat && !flags.contains("no_heating") && !disallowHeatingByBranch {
            flags.append("heating")
        }

        if flags.contains("heating") {
            steps.append("heating")
        }
        if flags.contains("late_addition") {
            steps.append("late_addition")
        }
        if flags.contains("separate_dissolution_stage") {
            steps.append("separate_dissolution_stage")
        }
        if flags.contains("prepare_combined_subsolution_first") {
            steps.append("prepare_combined_subsolution_first")
        }
        if flags.contains("no_heating") {
            steps.append("no_heating")
        }

        if disallowHeatingByBranch || flags.contains("no_heating") {
            steps = steps.filter { step in
                let token = SolutionReferenceStore.normalizeToken(step)
                return !(token.contains("heating") && token != "no_heating")
            }
        }

        if specialCases.contains(where: { $0.preDissolutionStageRequired }) && !flags.contains("separate_dissolution_stage") {
            warnings.append(
                SolutionWarning(
                    code: "requires_separate_dissolution_unhandled",
                    severity: .critical,
                    message: "Special dissolution case requires separate stage",
                    state: .technologyPlanBuilt
                )
            )
        }

        return (ModuleHelpers.uniqueOrdered(steps), ModuleHelpers.uniqueOrdered(flags), warnings)
    }
}

struct ValidationEngine {
    func validate(
        items: [SolutionBehaviorIngredient],
        branch: SolutionBranchResolution,
        route: SolutionRouteResolution,
        calculations: SolutionCalculationTrace,
        technologyFlags: [String],
        references: SolutionReferenceStore
    ) -> (warnings: [SolutionWarning], blocked: Bool, unresolvedRuleExists: Bool) {
        var warnings: [SolutionWarning] = []
        var blocked = false
        var unresolvedRuleExists = false

        let nonAdItems = items.filter { !$0.resolved.base.isAd }

        for item in nonAdItems {
            let presentation = item.resolved.base.presentationKind?.lowercased() ?? ""
            let treatedAsSolid = item.behavior?.countsAsSolid == true || ((item.resolved.base.massG ?? 0) > 0 && (item.behavior == nil))
            if ["solution", "standardsolution", "concentrate"].contains(presentation)
                && treatedAsSolid
                && !item.resolved.base.isTargetSolutionLine {
                warnings.append(ruleWarning("solution_treated_as_solid", references: references, state: .validationDone))
            }

            if calculations.kvoApplied,
               ["solution", "standardsolution", "concentrate"].contains(presentation) {
                warnings.append(ruleWarning("kvo_applied_to_ready_solution", references: references, state: .validationDone))
            }

            if let solubility = item.solubility {
                if solubility.requiresCoSolvent {
                    let hasNonAqueousSolvent = nonAdItems.contains {
                        ["alcohol", "glycerin", "oil", "mixedLiquid", "volatileSolvent"].contains($0.behavior?.behaviorType ?? "")
                            || ["alcohol", "glycerin", "oil", "volatile_solvent"].contains(($0.resolved.base.presentationKind ?? "").lowercased())
                    }
                    if !hasNonAqueousSolvent {
                        warnings.append(ruleWarning("co_solvent_required_but_missing", references: references, state: .validationDone))
                        warnings.append(ruleWarning("branch_not_allowed_for_substance", references: references, state: .validationDone))
                    }
                }

                if ["block_simple_aqueous_true_solution", "block_aqueous_true_solution"].contains(solubility.solutionGate),
                   branch.branch == "aqueous_true_solution" {
                    warnings.append(ruleWarning("blocked_aqueous_true_solution_used", references: references, state: .validationDone))
                }

                if !branchAllowedForSubstance(branch: branch.branch, allowed: solubility.allowedSolutionBranches) {
                    warnings.append(ruleWarning("branch_not_allowed_for_substance", references: references, state: .validationDone))
                }
            }

            if let specialCase = item.specialCase,
               specialCase.preDissolutionStageRequired,
               !technologyFlags.contains("separate_dissolution_stage") {
                warnings.append(ruleWarning("requires_separate_dissolution_unhandled", references: references, state: .validationDone))
                blocked = true
            }

            if let specialCase = item.specialCase,
               specialCase.blocksSimpleAutoPath,
               branch.branch == "aqueous_true_solution",
               specialCase.allowedBranches.allSatisfy({ !$0.contains("aqueous_true_solution") }) {
                warnings.append(ruleWarning("special_dissolution_case_ignored", references: references, state: .validationDone))
                blocked = true
            }

            if item.packaging?.requiresNoHeating == true,
               technologyFlags.contains("heating") {
                warnings.append(ruleWarning("no_heating_component_conflict", references: references, state: .validationDone))
                blocked = true
            }

            if item.packaging?.volatile == true,
               technologyFlags.contains("heating") {
                warnings.append(ruleWarning("volatile_component_heating_conflict", references: references, state: .validationDone))
                blocked = true
            }

            if item.packaging?.prefersAddAtEnd == true,
               !technologyFlags.contains("late_addition") {
                warnings.append(ruleWarning("late_addition_component_ignored", references: references, state: .validationDone))
            }
        }

        let hasWater = nonAdItems.contains { ($0.behavior?.behaviorType == "purifiedWater") || $0.resolved.base.normalizedName.contains("aqua") }
        let hasOil = nonAdItems.contains { $0.behavior?.behaviorType == "oil" }
        if hasWater && hasOil {
            warnings.append(ruleWarning("incompatible_solvent_phases", references: references, state: .validationDone))
            blocked = true
        }

        if let routePolicy = route.policy,
           !routePolicy.allowedSolutionBranches.isEmpty,
           !branchAllowedForRoute(branch: branch.branch, allowed: routePolicy.allowedSolutionBranches) {
            if ["inhalation", "injection", "ophthalmic"].contains(route.route) {
                warnings.append(ruleWarning("branch_not_allowed_for_route", references: references, state: .validationDone))
                blocked = true
            } else {
                warnings.append(ruleWarning("route_policy_conflict", references: references, state: .validationDone))
            }
        }

        if warnings.contains(where: { $0.code == "missing_behavior_profile" }) {
            unresolvedRuleExists = true
        }

        return (ModuleHelpers.uniqueOrderedWarnings(warnings), blocked, unresolvedRuleExists)
    }

    private func branchAllowedForSubstance(branch: String, allowed: [String]) -> Bool {
        let token = SolutionReferenceStore.normalizeToken(branch)
        for allowedBranch in allowed {
            let allowedToken = SolutionReferenceStore.normalizeToken(allowedBranch)
            if token == allowedToken {
                return true
            }
            if branch == "aqueous_true_solution" && allowedToken.contains("aqueous_true_solution") {
                return true
            }
            if branch == "aqueous_burette_solution" && allowedToken == "burette_concentrate_path" {
                return true
            }
            if branch == "special_dissolution_path" && allowedToken.contains("special") {
                return true
            }
            if branch == "non_aqueous_solution"
                && ["alcoholic_solution", "glycerinic_solution", "oily_solution", "volatile_non_aqueous_solution", "special_mixed_solution"].contains(allowedToken) {
                return true
            }
            if branch == "volatile_non_aqueous_solution"
                && ["volatile_non_aqueous_solution", "non_aqueous_solution", "alcoholic_solution", "glycerinic_solution", "oily_solution", "special_mixed_solution"].contains(allowedToken) {
                return true
            }
        }
        return false
    }

    private func branchAllowedForRoute(branch: String, allowed: [String]) -> Bool {
        let token = SolutionReferenceStore.normalizeToken(branch)
        for allowedBranch in allowed {
            let allowedToken = SolutionReferenceStore.normalizeToken(allowedBranch)
            if token == allowedToken {
                return true
            }
            if branch == "aqueous_true_solution" && allowedToken.contains("aqueous_true_solution") {
                return true
            }
            if branch == "aqueous_burette_solution" && allowedToken == "aqueous_burette_solution" {
                return true
            }
            if branch == "ready_solution_mix" && ["standard_solution_mix", "aqueous_true_solution"].contains(allowedToken) {
                return true
            }
            if branch == "standard_solution_mix" && allowedToken == "standard_solution_mix" {
                return true
            }
            if branch == "special_dissolution_path" && allowedToken.contains("special") {
                return true
            }
            if branch == "non_aqueous_solution"
                && ["non_aqueous_solution", "alcoholic_solution", "glycerinic_solution", "oily_solution", "volatile_non_aqueous_solution"].contains(allowedToken) {
                return true
            }
            if branch == "volatile_non_aqueous_solution"
                && ["volatile_non_aqueous_solution", "non_aqueous_solution", "alcoholic_solution", "glycerinic_solution", "oily_solution"].contains(allowedToken) {
                return true
            }
        }
        return false
    }

    private func ruleWarning(_ key: String, references: SolutionReferenceStore, state: SolutionEngineState) -> SolutionWarning {
        guard let rule = references.validationByRuleKey[key] else {
            return SolutionWarning(code: key, severity: .warning, message: key, state: state)
        }
        let severity: SolutionWarningSeverity
        switch rule.severity {
        case "critical": severity = .critical
        case "info": severity = .info
        default: severity = .warning
        }
        let message = rule.message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? rule.ruleKey : rule.message
        return SolutionWarning(code: rule.ruleKey, severity: severity, message: message, state: state)
    }
}

struct DoseValidator {
    func validate(
        signa: String,
        route: SolutionRouteResolution,
        items: [SolutionBehaviorIngredient],
        calculations: SolutionCalculationTrace,
        references: SolutionReferenceStore
    ) -> (dose: SolutionDoseControl, warnings: [SolutionWarning]) {
        var dose = SolutionDoseControl()
        var warnings: [SolutionWarning] = []

        let signaToken = SolutionReferenceStore.normalizeToken(signa)
        let doseInfo = parseDoseInfo(signaToken: signaToken, dictionary: references.normalizationDictionary)

        dose.singleDoseMl = doseInfo.singleDoseMl
        dose.frequencyPerDay = doseInfo.frequencyPerDay

        if let target = calculations.targetVolumeMl,
           let single = dose.singleDoseMl,
           single > 0 {
            let doses = target / single
            dose.dosesPerContainer = doses.rounded3()
            if doses.rounded() != doses {
                warnings.append(
                    SolutionWarning(
                        code: "dose_count_non_integer_unacknowledged",
                        severity: .info,
                        message: "Dose count per container is non-integer",
                        state: .doseControlDone
                    )
                )
            }
        }

        let requiresDoseControl = route.policy?.requiresDoseControlWhenApplicable == true
            || items.contains {
                ($0.resolved.safety?.safety.listA == true)
                    || ($0.resolved.safety?.safety.listB == true)
                    || ($0.resolved.safety?.safety.isNarcotic == true)
            }

        if requiresDoseControl,
           (dose.singleDoseMl == nil || dose.frequencyPerDay == nil) {
            warnings.append(
                SolutionWarning(
                    code: "dose_control_required_but_unresolved",
                    severity: .warning,
                    message: "Dose control required but signa could not be fully parsed",
                    state: .doseControlDone
                )
            )
        }

        return (dose, warnings)
    }

    private func parseDoseInfo(signaToken: String, dictionary: NormalizationDictionaryRoot) -> (singleDoseMl: Double?, frequencyPerDay: Int?) {
        var singleDoseMl: Double?
        var frequencyPerDay: Int?

        for (spoonKey, phrases) in dictionary.spoonDoseVocabulary {
            let match = phrases.contains { phrase in
                signaToken.contains(SolutionReferenceStore.normalizeToken(phrase))
            }
            if match {
                singleDoseMl = dictionary.spoonConversionsMl[spoonKey]
                break
            }
        }

        if singleDoseMl == nil {
            singleDoseMl = ModuleHelpers.parseNumber(
                ModuleHelpers.firstCapture(signaToken, pattern: #"(\d+(?:\.\d+)?)\s*(ml|мл)"#, group: 1, options: [.caseInsensitive])
            )
        }

        let frequencyMap: [String: Int] = [
            "once_daily": 1,
            "twice_daily": 2,
            "three_times_daily": 3,
            "four_times_daily": 4
        ]

        for (key, phrases) in dictionary.frequencyVocabulary {
            let match = phrases.contains { phrase in
                signaToken.contains(SolutionReferenceStore.normalizeToken(phrase))
            }
            if match, let value = frequencyMap[key] {
                frequencyPerDay = value
                break
            }
        }

        if frequencyPerDay == nil {
            if let parsed = ModuleHelpers.parseNumber(
                ModuleHelpers.firstCapture(signaToken, pattern: #"([1-9])\s*(?:раз|р/д|times?)"#, group: 1, options: [.caseInsensitive])
            ) {
                frequencyPerDay = Int(parsed)
            }
        }

        return (singleDoseMl, frequencyPerDay)
    }
}

struct PackagingResolver {
    func resolve(
        items: [SolutionBehaviorIngredient],
        route: SolutionRouteResolution,
        branch: SolutionBranchResolution
    ) -> (packaging: SolutionPackaging, warnings: [SolutionWarning]) {
        var packagingTokens: [String] = []
        var labelTokens: [String] = []
        var storageTokens: [String] = []
        var warnings: [SolutionWarning] = []

        if let routePolicy = route.policy {
            packagingTokens.append(contentsOf: mapPackagingToken(routePolicy.defaultPackaging))
            labelTokens.append(contentsOf: routePolicy.defaultLabels)
            labelTokens.append(contentsOf: routePolicy.additionalLabels)
        }

        for item in items {
            if let pack = item.packaging {
                packagingTokens.append(contentsOf: mapPackagingToken(pack.defaultPackaging))
                if pack.requiresDarkGlass { packagingTokens.append("dark_glass") }
                if pack.volatile { packagingTokens.append("tight_closure") }
                if pack.requiresCoolStorage { storageTokens.append("cool_storage") }
                if pack.requiresShakeLabel { labelTokens.append("shake_before_use") }
                storageTokens.append(contentsOf: pack.storageLabels)
                labelTokens.append(contentsOf: pack.defaultLabels)
            }
        }

        if branch.branch == "volatile_non_aqueous_solution" {
            packagingTokens.append("tight_closure")
        }

        if branch.branch == "aqueous_true_solution" && !items.contains(where: { $0.packaging?.requiresShakeLabel == true }) {
            labelTokens.removeAll { $0 == "shake_before_use" || $0.contains("shake") }
        }

        packagingTokens = ModuleHelpers.uniqueOrdered(packagingTokens)
        labelTokens = ModuleHelpers.uniqueOrdered(labelTokens)
        storageTokens = ModuleHelpers.uniqueOrdered(storageTokens)

        if items.contains(where: { $0.packaging?.requiresDarkGlass == true }), !packagingTokens.contains("dark_glass") {
            warnings.append(
                SolutionWarning(
                    code: "dark_glass_missing_when_required",
                    severity: .warning,
                    message: "Dark glass required by stability profile",
                    state: .packagingAndStorageDone
                )
            )
            packagingTokens.append("dark_glass")
        }

        if items.contains(where: { $0.packaging?.requiresCoolStorage == true }), !storageTokens.contains("cool_storage") {
            warnings.append(
                SolutionWarning(
                    code: "cool_storage_missing_when_required",
                    severity: .warning,
                    message: "Cool storage required by stability profile",
                    state: .packagingAndStorageDone
                )
            )
            storageTokens.append("cool_storage")
        }

        if items.contains(where: { $0.packaging?.volatile == true }), !packagingTokens.contains("tight_closure") {
            warnings.append(
                SolutionWarning(
                    code: "tight_closure_missing_for_volatile_system",
                    severity: .warning,
                    message: "Volatile system requires tight closure",
                    state: .packagingAndStorageDone
                )
            )
            packagingTokens.append("tight_closure")
        }

        return (SolutionPackaging(packaging: packagingTokens, labels: labelTokens, storage: storageTokens), warnings)
    }

    private func mapPackagingToken(_ raw: String) -> [String] {
        let token = SolutionReferenceStore.normalizeToken(raw)
        if token.contains("dark") {
            if token.contains("tight") {
                return ["dark_glass", "tight_closure"]
            }
            return ["dark_glass"]
        }
        if token.contains("tight") {
            return ["tight_closure"]
        }
        if token.contains("bottle") || token.contains("glass") {
            return ["glass_bottle"]
        }
        return token.isEmpty ? [] : [token]
    }
}

struct PPKRenderer {
    func render(
        parsedInput: SolutionParsedInput,
        branch: SolutionBranchResolution,
        route: SolutionRouteResolution,
        calculations: SolutionCalculationTrace,
        technologySteps: [String],
        warnings: [SolutionWarning],
        packaging: SolutionPackaging,
        references: SolutionReferenceStore
    ) -> (document: SolutionPPKDocument, warnings: [SolutionWarning]) {
        var sections: [String: [String]] = [:]
        var renderWarnings: [SolutionWarning] = []

        sections["input_data"] = [
            "Dosage form: \(parsedInput.dosageForm)",
            "Route: \(route.route)",
            "Branch: \(branch.branch)"
        ]

        sections["calculations"] = calculations.lines + [
            "sumSolidsG=\(format(calculations.sumSolidsG))",
            "sumCountedLiquidsMl=\(format(calculations.sumCountedLiquidsMl))",
            "waterToAddMl=\(format(calculations.waterToAddMl ?? 0))"
        ]

        sections["technology"] = technologySteps
        sections["validation"] = warnings.map { "\($0.code): \($0.message)" }
        sections["packaging"] = [
            "packaging=\(packaging.packaging.joined(separator: ","))",
            "labels=\(packaging.labels.joined(separator: ","))",
            "storage=\(packaging.storage.joined(separator: ","))"
        ]

        let requiredSectionKeys = references.ppkPhraseRules.sectionTemplates
            .filter { $0.required == true }
            .map(\.sectionKey)

        for requiredKey in requiredSectionKeys where sections[requiredKey] == nil {
            sections[requiredKey] = []
        }

        var ordered: [String] = []
        for template in references.ppkPhraseRules.sectionTemplates {
            if sections[template.sectionKey] != nil {
                ordered.append(template.sectionKey)
            }
        }

        for key in sections.keys where !ordered.contains(key) {
            ordered.append(key)
        }

        var renderedLines: [String] = []
        var seenSections: Set<String> = []

        for key in ordered {
            guard let lines = sections[key] else { continue }
            if seenSections.contains(key) {
                renderWarnings.append(
                    SolutionWarning(
                        code: "duplicate_section_render",
                        severity: .warning,
                        message: "Duplicate section \(key) removed",
                        state: .ppcRendered
                    )
                )
                continue
            }
            seenSections.insert(key)

            renderedLines.append("[\(key)]")
            renderedLines.append(contentsOf: lines)
            renderedLines.append("")
        }

        let forbidden = references.ppkPhraseRules.forbiddenUniversalPhrases ?? []
        let sanitized = renderedLines.filter { line in
            !forbidden.contains(where: { forbiddenToken in
                let token = forbiddenToken.trimmingCharacters(in: .whitespacesAndNewlines)
                return !token.isEmpty && line.contains(token)
            })
        }

        if sanitized != renderedLines {
            renderWarnings.append(
                SolutionWarning(
                    code: "stock_qc_text_leak",
                    severity: .critical,
                    message: "Forbidden stock QC phrases removed from final PPC",
                    state: .ppcRendered
                )
            )
        }

        return (SolutionPPKDocument(sections: sections, renderedText: sanitized.joined(separator: "\n")), renderWarnings)
    }

    private func format(_ value: Double) -> String {
        if value == floor(value) {
            return String(Int(value))
        }
        return String(format: "%.3f", value)
    }
}

private extension ModuleHelpers {
    static func uniqueOrderedWarnings(_ warnings: [SolutionWarning]) -> [SolutionWarning] {
        var seen: Set<String> = []
        var result: [SolutionWarning] = []
        for warning in warnings {
            let key = "\(warning.code)|\(warning.severity.rawValue)|\(warning.state?.rawValue ?? "")"
            if seen.insert(key).inserted {
                result.append(warning)
            }
        }
        return result
    }
}
