import Foundation

struct RxFixtureScenario {
    let id: String
    let title: String
    let draft: ExtempRecipeDraft
    let expectedActivatedBlocks: [String]
    let forbiddenActivatedBlocks: [String]
    let expectedSectionTitles: [String]
    let expectedLineFragments: [String]
    let forbiddenLineFragments: [String]
    let validator: ((RuleResult) -> [String])?

    init(
        id: String,
        title: String,
        draft: ExtempRecipeDraft,
        expectedActivatedBlocks: [String],
        forbiddenActivatedBlocks: [String],
        expectedSectionTitles: [String],
        expectedLineFragments: [String] = [],
        forbiddenLineFragments: [String] = [],
        validator: ((RuleResult) -> [String])? = nil
    ) {
        self.id = id
        self.title = title
        self.draft = draft
        self.expectedActivatedBlocks = expectedActivatedBlocks
        self.forbiddenActivatedBlocks = forbiddenActivatedBlocks
        self.expectedSectionTitles = expectedSectionTitles
        self.expectedLineFragments = expectedLineFragments
        self.forbiddenLineFragments = forbiddenLineFragments
        self.validator = validator
    }
}

struct RxFixtureResult {
    let scenarioId: String
    let passed: Bool
    let details: [String]
}

enum RxFixtureScenarios {
    static func all() -> [RxFixtureScenario] {
        [
            waterKuoScenario(),
            standardDemyanovichScenario(),
            hydrochloricAcidDilutionScenario(),
            hydrogenPeroxideDilutionScenario(),
            ethanolExternalSolutionScenario(),
            ethanolSolutionScenario(),
            glycerinSolutionScenario(),
            glycerinIodineComplexScenario(),
            ethanolRinseMeasuredByDropsScenario(),
            oilEarDropsScenario(),
            dropsDoseScenario(),
            furacilinRatioSolutionScenario(),
            silverNitrateSolutionScenario(),
            iodineKiAqueousScenario(),
            tweenSpanConflictWaterScenario(),
            concentratedPermanganateScenario(),
            platyphylliniDropsScenario(),
            platyphylliniListADropsScenario(),
            infusionScenario(),
            decoctionTanninHotFiltrationScenario(),
            vmsProtargolGlycerinScenario(),
            nonAqueousTweenSpanConflictScenario(),
            nonAqueousChloroformParaffinScenario(),
            powderNewbornAsepticScenario(),
            listAPowderScenario(),
            listBPowderScenario(),
            buretteAqueousConcentratesScenario(),
            nonBuretteEquivalentScenario(),
            multipleSolutionIngredientsScenario(),
            buretteMassDerivationFailureScenario()
        ]
    }

    static func run(engine: RuleEngineProtocol = DefaultRuleEngine()) -> [RxFixtureResult] {
        all().map { scenario in
            let evaluated = engine.evaluate(draft: scenario.draft)

            var details: [String] = []
            var ok = true

            for block in scenario.expectedActivatedBlocks {
                if !evaluated.derived.activatedBlocks.contains(block) {
                    ok = false
                    details.append("missing block: \(block)")
                }
            }

            for block in scenario.forbiddenActivatedBlocks {
                if evaluated.derived.activatedBlocks.contains(block) {
                    ok = false
                    details.append("unexpected block: \(block)")
                }
            }

            let sectionTitles = Set(evaluated.derived.ppkSections.map(\.title))
            for title in scenario.expectedSectionTitles {
                if !sectionTitles.contains(title) {
                    ok = false
                    details.append("missing section: \(title)")
                }
            }

            let renderedLines = evaluated.derived.ppkSections
                .flatMap(\.lines)
                .joined(separator: "\n")
            for fragment in scenario.expectedLineFragments {
                if !renderedLines.contains(fragment) {
                    ok = false
                    details.append("missing fragment: \(fragment)")
                }
            }
            for fragment in scenario.forbiddenLineFragments {
                if renderedLines.contains(fragment) {
                    ok = false
                    details.append("unexpected fragment: \(fragment)")
                }
            }
            if let validator = scenario.validator {
                let validatorIssues = validator(evaluated)
                if !validatorIssues.isEmpty {
                    ok = false
                    details.append(contentsOf: validatorIssues)
                }
            }

            if details.isEmpty {
                details.append("ok")
            }

            return RxFixtureResult(scenarioId: scenario.id, passed: ok, details: details)
        }
    }

    private static func waterKuoScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.signa = "По 1 столовой ложке 3 раза в день"
        d.targetValue = 100
        d.targetUnit = UnitCode(rawValue: "ml")
        d.ingredients = [
            IngredientDraft(
                displayName: "Natrii bromidum",
                role: .active,
                amountValue: 4,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refKuoMlPerG: 0.27,
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 100,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "water_kuo",
            title: "Water solution >=3% with KUO",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, WaterSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Розрахунки", "Технологія", "Контроль якості"]
        )
    }

    private static func standardDemyanovichScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.useStandardSolutionsBlock = true
        d.signa = "Раствор №2 по Демьяновичу"
        d.ingredients = [
            IngredientDraft(
                displayName: "Acidum hydrochloricum 6%",
                role: .active,
                amountValue: 200,
                unit: UnitCode(rawValue: "ml"),
                refType: "act",
                refNameLatNom: "Acidum hydrochloricum 6%",
            )
        ]

        return RxFixtureScenario(
            id: "std_demyanovich",
            title: "Standard solution Demyanovich #2",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, StandardSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Розрахунки (ГФ: стандартні розчини)", "Технологія"],
            expectedLineFragments: [
                "Фармакопейний еквівалент для розчину №2 за Дем'яновичем: кислота 24,8–25,2% 12 ml + Aqua purificata ad 200 ml",
                "Фактичне виготовлення з Acidum hydrochloricum dilutum 8,3%: 36 ml + Aqua purificata 164 ml",
                "У підставку: Aqua purificata 164 ml",
                "Додати: Кислота хлористоводородная разведенная 8,3% 36 ml"
            ]
        )
    }

    private static func hydrochloricAcidDilutionScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.useStandardSolutionsBlock = true
        d.signa = "По 1 чайной ложке 3 раза в день"
        d.ingredients = [
            IngredientDraft(
                displayName: "Acidum hydrochloricum 2%",
                role: .active,
                amountValue: 200,
                unit: UnitCode(rawValue: "ml"),
                refType: "act",
                refNameLatNom: "Acidum hydrochloricum 2%"
            )
        ]

        return RxFixtureScenario(
            id: "std_hcl_2pct",
            title: "Hydrochloric acid 2% uses stock-solution percent rule",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, StandardSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Розрахунки (ГФ: стандартні розчини)", "Технологія"],
            expectedLineFragments: [
                "Кислота хлористоводородная разведенная 2%: 4 ml + Aqua purificata ad 200 ml",
                "Додати: Кислота хлористоводородная разведенная 8,3% 4 ml"
            ]
        )
    }

    private static func hydrogenPeroxideDilutionScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.useStandardSolutionsBlock = true
        d.signa = "Зовнішньо"
        d.ingredients = [
            IngredientDraft(
                displayName: "Hydrogenii peroxydi 5%",
                role: .active,
                amountValue: 100,
                unit: UnitCode(rawValue: "ml"),
                refType: "act",
                refNameLatNom: "Hydrogenii peroxydi 5%"
            )
        ]

        return RxFixtureScenario(
            id: "std_h2o2_5pct",
            title: "Peroxide 5% uses concentrated stock ratio",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, StandardSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Розрахунки (ГФ: стандартні розчини)", "Технологія"],
            expectedLineFragments: ["Відміряти: Раствор водорода перекиси концентрированный 30% 16.667 ml"]
        )
    }

    private static func ethanolExternalSolutionScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .alcoholSolution
        d.signa = "Протирать кожу лица"
        d.ingredients = [
            IngredientDraft(
                displayName: "Spiritus salicylicus 1%",
                role: .active,
                amountValue: 10,
                unit: UnitCode(rawValue: "ml"),
                refType: "act",
                refNameLatNom: "Spiritus salicylicus 1%",
                refSolventType: "ethanol"
            )
        ]

        return RxFixtureScenario(
            id: "ethanol_external_solution",
            title: "External alcohol solution is not mouth rinse",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, NonAqueousSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [DropDoseSupportBlock.blockId, DropsBlock.blockId],
            expectedSectionTitles: ["Технологія виготовлення", "Логіка неводного розчину"]
        )
    }

    private static func ethanolSolutionScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .alcoholSolution
        d.signa = "Зовнішньо"
        d.targetValue = 100
        d.targetUnit = UnitCode(rawValue: "ml")
        d.ingredients = [
            IngredientDraft(
                displayName: "Iodi",
                role: .active,
                amountValue: 2,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Iodi",
                refSolubility: "Дуже мало розчинний у воді, розчинний у спирті"
            ),
            IngredientDraft(
                displayName: "Spiritus aethylici 70%",
                role: .solvent,
                amountValue: 100,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent",
                refNameLatNom: "Spiritus aethylici 70%",
                refDensity: 0.89,
                refSolventType: "ethanol"
            )
        ]

        return RxFixtureScenario(
            id: "ethanol_solution",
            title: "Non-aqueous ethanol solution uses dedicated block",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, NonAqueousSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [DropsBlock.blockId],
            expectedSectionTitles: ["Розрахунки", "Технологія виготовлення", "Контроль якості", "Логіка неводного розчину"]
        )
    }

    private static func glycerinSolutionScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.signa = "Для змащування"
        d.targetValue = 50
        d.targetUnit = UnitCode(rawValue: "ml")
        d.ingredients = [
            IngredientDraft(
                displayName: "Natrii tetraboratis",
                role: .active,
                amountValue: 5,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Natrii tetraboratis",
                refSolubility: "Розчинний у гліцерині при нагріванні"
            ),
            IngredientDraft(
                displayName: "Glycerinum",
                role: .solvent,
                amountValue: 50,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent",
                refNameLatNom: "Glycerinum",
                refDensity: 1.228,
                refSolventType: "glycerin"
            )
        ]

        return RxFixtureScenario(
            id: "glycerin_solution",
            title: "Glycerin solution auto-routes as non-aqueous",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, NonAqueousSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [DropsBlock.blockId, StrongControlBlock.blockId, PoisonControlBlock.blockId],
            expectedSectionTitles: ["Розрахунки", "Технологія виготовлення", "Контроль якості", "Логіка неводного розчину"]
        )
    }

    private static func glycerinIodineComplexScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.signa = "Для зовнішнього застосування"
        d.targetValue = 10
        d.targetUnit = UnitCode(rawValue: "g")
        d.ingredients = [
            IngredientDraft(
                displayName: "Iodum",
                role: .active,
                amountValue: 0.05,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Iodum"
            ),
            IngredientDraft(
                displayName: "Kalii iodidum",
                role: .active,
                amountValue: 0.1,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Kalii iodidum"
            ),
            IngredientDraft(
                displayName: "Glycerinum",
                role: .solvent,
                amountValue: 10,
                unit: UnitCode(rawValue: "g"),
                isAd: true,
                refType: "solvent",
                refNameLatNom: "Glycerinum",
                refDensity: 1.228,
                refSolventType: "glycerin"
            )
        ]

        return RxFixtureScenario(
            id: "glycerin_iodine_complex",
            title: "Iodine in glycerin requires iodide complex path",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, NonAqueousSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [DropsBlock.blockId],
            expectedSectionTitles: ["Розрахунки", "Технологія виготовлення", "Контроль якості", "Логіка неводного розчину"]
        )
    }

    private static func ethanolRinseMeasuredByDropsScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .drops
        d.liquidTechnologyMode = .alcoholSolution
        d.signa = "По 10 капель на 0,5 стакана воды для полоскания"
        d.ingredients = [
            IngredientDraft(
                displayName: "Mentholi",
                role: .active,
                amountValue: 0.1,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Mentholum",
                refSolubility: "Практично нерозчинний у воді, дуже легко розчинний у спирті"
            ),
            IngredientDraft(
                displayName: "Thymoli",
                role: .active,
                amountValue: 0.1,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Thymolum",
                refSolubility: "1:1100 H2O, 1:1 Alcohol, 1:3 Oils",
                refInteractionNotes: "Образует эвтектические смеси с камфорой, ментолом и хлоралгидратом"
            ),
            IngredientDraft(
                displayName: "Spiritus aethylici 90%",
                role: .solvent,
                amountValue: 10,
                unit: UnitCode(rawValue: "ml"),
                refType: "solvent",
                refNameLatNom: "Spiritus aethylici 90%",
                refDensity: 0.833,
                refSolventType: "ethanol"
            )
        ]

        return RxFixtureScenario(
            id: "ethanol_rinse_measured_by_drops",
            title: "Drops in signa can still mean alcohol rinse solution",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, NonAqueousSolutionsBlock.blockId, DropDoseSupportBlock.blockId],
            forbiddenActivatedBlocks: [DropsBlock.blockId],
            expectedSectionTitles: ["Технологія виготовлення", "Логіка неводного розчину", "Контроль доз"]
        )
    }

    private static func oilEarDropsScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .drops
        d.signa = "По 2 капли в ухо 2 раза в день"
        d.ingredients = [
            IngredientDraft(
                displayName: "Acidi carbolici",
                role: .active,
                amountValue: 0.1,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Phenolum"
            ),
            IngredientDraft(
                displayName: "Oleum Helianthi",
                role: .solvent,
                amountValue: 5,
                unit: UnitCode(rawValue: "ml"),
                refType: "solvent",
                refNameLatNom: "Oleum Helianthi",
                refSolventType: "fatty_oil"
            )
        ]

        return RxFixtureScenario(
            id: "oil_ear_drops",
            title: "Non-aqueous ear drops combine solvent tech and drop metrology",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, NonAqueousSolutionsBlock.blockId, DropsBlock.blockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Технологія виготовлення", "Контроль доз", "Оформлення"]
        )
    }

    private static func dropsDoseScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .drops
        d.isOphthalmicDrops = false
        d.signa = "По 10 капель 3 раза в день"
        d.ingredients = [
            IngredientDraft(
                displayName: "Tinctura Valerianae",
                role: .active,
                amountValue: 20,
                unit: UnitCode(rawValue: "ml"),
                refType: "tincture",
                refGttsPerMl: 50,
            ),
            IngredientDraft(
                displayName: "Natrii bromidum",
                role: .active,
                amountValue: 2,
                unit: UnitCode(rawValue: "g"),
                refType: "act"
            )
        ]

        return RxFixtureScenario(
            id: "drops_dose",
            title: "Drops with dose control",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, DropsBlock.blockId],
            forbiddenActivatedBlocks: [NonAqueousSolutionsBlock.blockId],
            expectedSectionTitles: ["Розрахунки", "Контроль доз", "Технологія"]
        )
    }

    private static func furacilinRatioSolutionScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.targetValue = 250
        d.targetUnit = UnitCode(rawValue: "ml")
        d.signa = "Полоскання"
        d.ingredients = [
            IngredientDraft(
                displayName: "Furacilinum",
                role: .active,
                amountValue: 250,
                unit: UnitCode(rawValue: "ml"),
                presentationKind: .solution,
                refType: "act",
                refNameLatNom: "Solutionis Furacilini 1:5000"
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 250,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "furacilin_ratio_solution",
            title: "Furacilinum 1:5000 uses ratio mass calculation and boiling-water notes",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, WaterSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [NonAqueousSolutionsBlock.blockId],
            expectedSectionTitles: ["Розрахунки", "Стабільність", "Технологія"],
            expectedLineFragments: []
        )
    }

    private static func silverNitrateSolutionScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.targetValue = 300
        d.targetUnit = UnitCode(rawValue: "ml")
        d.signa = "Для промивання сечового міхура"
        d.ingredients = [
            IngredientDraft(
                displayName: "Argenti nitras",
                role: .active,
                amountValue: 1.5,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Argenti nitras",
                refListA: true
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 300,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "silver_nitrate_solution",
            title: "Silver nitrate water solution triggers List A and distilled-water technology notes",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, WaterSolutionsBlock.blockId, PoisonControlBlock.blockId],
            forbiddenActivatedBlocks: [NonAqueousSolutionsBlock.blockId],
            expectedSectionTitles: ["Контроль доз", "Технологія", "Упаковка/Маркування"],
            expectedLineFragments: []
        )
    }

    private static func iodineKiAqueousScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.targetValue = 10
        d.targetUnit = UnitCode(rawValue: "ml")
        d.signa = "Для обробки шкіри"
        d.ingredients = [
            IngredientDraft(
                displayName: "Iodi",
                role: .active,
                amountValue: 0.05,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Iodi"
            ),
            IngredientDraft(
                displayName: "Kalii iodidum",
                role: .active,
                amountValue: 0.1,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Kalii iodidum"
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 10,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "iodine_ki_aqueous",
            title: "Iodine + iodide in water builds sequential complex-formation instructions",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, WaterSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [NonAqueousSolutionsBlock.blockId],
            expectedSectionTitles: ["Розрахунки", "Технологія"],
            expectedLineFragments: [
                "Iodine/KI:",
                "Йодну систему готувати послідовно"
            ]
        )
    }

    private static func tweenSpanConflictWaterScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.targetValue = 100
        d.targetUnit = UnitCode(rawValue: "ml")
        d.signa = "Зовнішньо"
        d.ingredients = [
            IngredientDraft(
                displayName: "Tween-80",
                role: .active,
                amountValue: 1,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Tween-80"
            ),
            IngredientDraft(
                displayName: "Natrii salicylatis",
                role: .active,
                amountValue: 1,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Natrii salicylatis"
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 100,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "water_tween_span_conflict",
            title: "Tween/Span incompatibility is raised in aqueous solutions",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, WaterSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [NonAqueousSolutionsBlock.blockId],
            expectedSectionTitles: ["Стабільність", "Технологія"],
            expectedLineFragments: [
                "несумісні із саліцилатами/фенолами/похідними параоксибензойної кислоти"
            ]
        )
    }

    private static func concentratedPermanganateScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.targetValue = 100
        d.targetUnit = UnitCode(rawValue: "ml")
        d.signa = "Зовнішньо"
        d.ingredients = [
            IngredientDraft(
                displayName: "Kalii permanganatis",
                role: .active,
                amountValue: 4,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Kalii permanganatis"
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 100,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "water_permanganate_concentrated",
            title: "Concentrated potassium permanganate uses trituration pre-step",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, WaterSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [NonAqueousSolutionsBlock.blockId],
            expectedSectionTitles: ["Стабільність", "Технологія"],
            expectedLineFragments: [
                "концентрованого розчину 4%",
                "попередньо обережно розтерти кристали"
            ]
        )
    }

    private static func decoctionTanninHotFiltrationScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .decoction
        d.signa = "По 1 столовій ложці 3 рази на день"
        d.ingredients = [
            IngredientDraft(
                displayName: "Cortex Quercus",
                role: .active,
                amountValue: 10,
                unit: UnitCode(rawValue: "g"),
                refType: "herbalraw",
                refPrepMethod: "decoctum",
                refHerbalRatio: "1:10"
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 100,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "decoction_tannin_hot_filtration",
            title: "Tannin-rich decoction requires immediate hot filtration",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, InfusionDecoctionBlock.decoctionBlockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Технологія"],
            expectedLineFragments: [
                "відразу проціджувати гарячим"
            ]
        )
    }

    private static func vmsProtargolGlycerinScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.useVmsColloidsBlock = true
        d.targetValue = 10
        d.targetUnit = UnitCode(rawValue: "ml")
        d.signa = "Для промивання"
        d.ingredients = [
            IngredientDraft(
                displayName: "Protargolum",
                role: .active,
                amountValue: 0.3,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Protargolum"
            ),
            IngredientDraft(
                displayName: "Glycerinum",
                role: .excipient,
                amountValue: 0.3,
                unit: UnitCode(rawValue: "ml"),
                refType: "aux",
                refNameLatNom: "Glycerinum"
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 10,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "vms_protargol_glycerin",
            title: "Protargol with glycerin uses pre-trituration path",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, NonAqueousSolutionsBlock.blockId, VMSColloidsBlock.blockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Технологія"],
            expectedLineFragments: [
                "6–8 краплями гліцерину"
            ]
        )
    }

    private static func nonAqueousTweenSpanConflictScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.signa = "Зовнішньо"
        d.targetValue = 30
        d.targetUnit = UnitCode(rawValue: "g")
        d.ingredients = [
            IngredientDraft(
                displayName: "Tween-80",
                role: .active,
                amountValue: 0.5,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Tween-80"
            ),
            IngredientDraft(
                displayName: "Natrii salicylatis",
                role: .active,
                amountValue: 0.5,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Natrii salicylatis"
            ),
            IngredientDraft(
                displayName: "Glycerinum",
                role: .solvent,
                amountValue: 30,
                unit: UnitCode(rawValue: "g"),
                isAd: true,
                refType: "solvent",
                refNameLatNom: "Glycerinum",
                refDensity: 1.228,
                refSolventType: "glycerin"
            )
        ]

        return RxFixtureScenario(
            id: "nonaqueous_tween_span_conflict",
            title: "Tween/Span incompatibility is raised in non-aqueous solutions",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, NonAqueousSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [WaterSolutionsBlock.blockId],
            expectedSectionTitles: ["Технологія виготовлення", "Логіка неводного розчину"],
            expectedLineFragments: []
        )
    }

    private static func nonAqueousChloroformParaffinScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .alcoholSolution
        d.signa = "Зовнішньо"
        d.targetValue = 20
        d.targetUnit = UnitCode(rawValue: "ml")
        d.ingredients = [
            IngredientDraft(
                displayName: "Paraffinum",
                role: .active,
                amountValue: 1,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Paraffinum"
            ),
            IngredientDraft(
                displayName: "Chloroformium",
                role: .solvent,
                amountValue: 20,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent",
                refNameLatNom: "Chloroformium",
                refSolventType: "chloroform"
            )
        ]

        return RxFixtureScenario(
            id: "nonaqueous_chloroform_paraffin",
            title: "Chloroform with paraffin gets cautious heating instruction",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, NonAqueousSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [WaterSolutionsBlock.blockId],
            expectedSectionTitles: ["Технологія виготовлення", "Логіка неводного розчину"],
            expectedLineFragments: [
                "Chloroformium + Paraffinum"
            ]
        )
    }

    private static func powderNewbornAsepticScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .powders
        d.numero = 10
        d.signa = "Для новонародженого: по 1 порошку 2 рази на день"
        d.ingredients = [
            IngredientDraft(
                displayName: "Zinci oxydum",
                role: .active,
                amountValue: 0.1,
                unit: UnitCode(rawValue: "g"),
                scope: .perDose,
                refType: "act",
                refNameLatNom: "Zinci oxydum"
            ),
            IngredientDraft(
                displayName: "Sacchari lactis",
                role: .excipient,
                amountValue: 0.25,
                unit: UnitCode(rawValue: "g"),
                scope: .perDose,
                refType: "aux",
                refNameLatNom: "Sacchari lactis"
            )
        ]

        return RxFixtureScenario(
            id: "powder_newborn_aseptic",
            title: "Powders for newborns require aseptic manufacturing",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, PowdersTriturationsBlock.blockId],
            forbiddenActivatedBlocks: [PoisonControlBlock.blockId, StrongControlBlock.blockId],
            expectedSectionTitles: ["Технологія", "Оформлення та зберігання"],
            expectedLineFragments: [
                "порошок для новонародженого"
            ]
        )
    }

    private static func platyphylliniDropsScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .drops
        d.isOphthalmicDrops = false
        d.signa = "По 10 капель 3 раза в день"
        d.ingredients = [
            IngredientDraft(
                displayName: "Platyphyllini hydrotartras",
                role: .active,
                amountValue: 0.04,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Platyphyllini hydrotartras",
                refVrdG: 0.01,
                refVsdG: 0.03,
                refListB: true
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 20,
                unit: UnitCode(rawValue: "ml"),
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "platyphyllini_drops",
            title: "List B drops (Platyphyllini) should be included in dose checks",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, DropsBlock.blockId],
            forbiddenActivatedBlocks: [NonAqueousSolutionsBlock.blockId],
            expectedSectionTitles: ["Контроль доз"]
        )
    }

    private static func platyphylliniListADropsScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .drops
        d.isOphthalmicDrops = false
        d.signa = "По 10 капель 3 раза в день"
        d.ingredients = [
            IngredientDraft(
                displayName: "Platyphyllini hydrotartras",
                role: .active,
                amountValue: 0.05,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Platyphyllini hydrotartras",
                refVrdG: 0.01,
                refVsdG: 0.03,
                refListA: true
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 10,
                unit: UnitCode(rawValue: "ml"),
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "platyphyllini_lista_drops",
            title: "List A drops (Platyphyllini) should not block dose calculation when VRD/VSD are present",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, DropsBlock.blockId, PoisonControlBlock.blockId],
            forbiddenActivatedBlocks: [NonAqueousSolutionsBlock.blockId],
            expectedSectionTitles: ["Контроль доз", "Контроль списку А"]
        )
    }

    private static func infusionScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .infusion
        d.signa = "По 1/3 стакана 3 раза в день"
        d.ingredients = [
            IngredientDraft(
                displayName: "Herba Leonuri",
                role: .active,
                amountValue: 10,
                unit: UnitCode(rawValue: "g"),
                refType: "herbalraw",
                refPrepMethod: "infusum",
                refHerbalRatio: "1:10",
                refWaterTempC: 100,
                refHeatBathMin: 15,
                refStandMin: 45,
                refStrain: true,
                refBringToVolume: true
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 100,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "infusion",
            title: "Infusion by reference metadata",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, InfusionDecoctionBlock.infusionBlockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Технологія"]
        )
    }

    private static func listAPowderScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .powders
        d.numero = 10
        d.ingredients = [
            IngredientDraft(
                displayName: "Atropini sulfatis",
                role: .active,
                amountValue: 0.0005,
                unit: UnitCode(rawValue: "g"),
                scope: .perDose,
                refType: "act",
                refNameLatNom: "Atropini sulfatis",
                refVrdG: 0.001,
                refVsdG: 0.003,
                refListA: true
            ),
            IngredientDraft(
                displayName: "Sacchari lactis",
                role: .excipient,
                amountValue: 0.3,
                unit: UnitCode(rawValue: "g"),
                scope: .perDose,
                refType: "aux",
                refNameLatNom: "Sacchari lactis"
            )
        ]

        return RxFixtureScenario(
            id: "lista_powder",
            title: "List A powders use poison powder resolver only",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, PoisonControlBlock.blockId],
            forbiddenActivatedBlocks: [StrongControlBlock.blockId],
            expectedSectionTitles: ["Розрахунки", "Контроль доз", "Технологія Списку А"]
        )
    }

    private static func listBPowderScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .powders
        d.numero = 10
        d.ingredients = [
            IngredientDraft(
                displayName: "Substantia fortis",
                role: .active,
                amountValue: 0.002,
                unit: UnitCode(rawValue: "g"),
                scope: .perDose,
                refType: "act",
                refNameLatNom: "Substantia fortis",
                refVrdG: 0.01,
                refVsdG: 0.03,
                refListB: true,
                refPharmActivity: "Сильнодействующие"
            ),
            IngredientDraft(
                displayName: "Sacchari lactis",
                role: .excipient,
                amountValue: 0.3,
                unit: UnitCode(rawValue: "g"),
                scope: .perDose,
                refType: "aux",
                refNameLatNom: "Sacchari lactis"
            )
        ]

        return RxFixtureScenario(
            id: "listb_powder",
            title: "List B powders use strong powder resolver only",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, StrongControlBlock.blockId],
            forbiddenActivatedBlocks: [PoisonControlBlock.blockId],
            expectedSectionTitles: ["Розрахунки", "Контроль доз", "Технологія Списку Б"]
        )
    }

    private static func buretteAqueousConcentratesScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.useBuretteSystem = true
        d.targetValue = 150
        d.targetUnit = UnitCode(rawValue: "ml")
        d.signa = "По 1 столовой ложке 3 раза в день"
        d.solPercent = 2
        d.solPercentInputText = "2"
        d.solVolumeMl = 150
        d.ingredients = [
            IngredientDraft(
                displayName: "Sol. Natrii bromidi 2%",
                role: .active,
                amountValue: 150,
                unit: UnitCode(rawValue: "ml"),
                presentationKind: .solution,
                refType: "act",
                refNameLatNom: "Sol. Natrii bromidi 2%"
            ),
            IngredientDraft(
                displayName: "Coffeini-natrii benzoas",
                role: .active,
                amountValue: 1,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Coffeini-natrii benzoas"
            ),
            IngredientDraft(
                displayName: "Glucosi",
                role: .active,
                amountValue: 6,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Glucosi"
            )
        ]

        return RxFixtureScenario(
            id: "burette_aqueous_concentrates",
            title: "Burette aqueous recipe derives masses and volumes from Sol.% + V",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, BuretteSystemBlock.blockId, WaterSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Бюреточні розрахунки", "Розрахунки", "Технологія"],
            expectedLineFragments: [
                "Раствор натрия бромида 20%: V_conc = 3 / 0,2 = 15 ml",
                "Раствор кофеина-натрия бензоата 10%: V_conc = 1 / 0,1 = 10 ml",
                "Раствор глюкозы 50%: V_conc = 6 / 0,5 = 12 ml",
                "ΣV_концентратів = 37 ml",
                "Aqua purificata = 113 ml"
            ],
            forbiddenLineFragments: [
                "Раствор натрия бромида 20%: V_conc = 0",
                "КУО перевищує 3% від об'єму",
                "Гілка: ≥3% (з КУО)"
            ],
            validator: { evaluated in
                var errors: [String] = []
                if evaluated.derived.calculations["ignore_kuo_for_burette"] != "true" {
                    errors.append("missing calculation flag: ignore_kuo_for_burette")
                }
                if evaluated.issues.contains(where: { $0.message.contains("КУО перевищує 3%") }) {
                    errors.append("unexpected KУО>3% warning in burette mode")
                }
                return errors
            }
        )
    }

    private static func nonBuretteEquivalentScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.useBuretteSystem = false
        d.targetValue = 150
        d.targetUnit = UnitCode(rawValue: "ml")
        d.signa = "По 1 столовой ложке 3 раза в день"
        d.ingredients = [
            IngredientDraft(
                displayName: "Natrii bromidum",
                role: .active,
                amountValue: 3,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Natrii bromidum",
                refKuoMlPerG: 0.23
            ),
            IngredientDraft(
                displayName: "Coffeini-natrii benzoas",
                role: .active,
                amountValue: 1,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Coffeini-natrii benzoas",
                refKuoMlPerG: 0.6
            ),
            IngredientDraft(
                displayName: "Glucosi",
                role: .active,
                amountValue: 6,
                unit: UnitCode(rawValue: "g"),
                refType: "act",
                refNameLatNom: "Glucosi",
                refKuoMlPerG: 0.69
            ),
            IngredientDraft(
                displayName: "Aqua purificata",
                role: .solvent,
                amountValue: 150,
                unit: UnitCode(rawValue: "ml"),
                isAd: true,
                refType: "solvent"
            )
        ]

        return RxFixtureScenario(
            id: "non_burette_equivalent",
            title: "Equivalent aqueous recipe without burette uses standard KUO branch",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, WaterSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [BuretteSystemBlock.blockId],
            expectedSectionTitles: ["Розрахунки", "Технологія"],
            expectedLineFragments: [
                "Гілка: ≥3% (з КУО)",
                "ΣКУО ="
            ],
            forbiddenLineFragments: [
                "КУО: не застосовується (компоненти внесено як концентровані розчини)"
            ],
            validator: { evaluated in
                evaluated.derived.calculations["ignore_kuo_for_burette"] == nil
                    ? []
                    : ["unexpected calculation flag: ignore_kuo_for_burette"]
            }
        )
    }

    private static func multipleSolutionIngredientsScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.targetValue = 100
        d.targetUnit = UnitCode(rawValue: "ml")
        d.signa = "По 1 столовой ложке 3 раза в день"
        d.solPercent = 2
        d.solPercentInputText = "2"
        d.solVolumeMl = 50
        d.ingredients = [
            IngredientDraft(
                displayName: "Sol. Natrii bromidi 2%",
                role: .active,
                amountValue: 50,
                unit: UnitCode(rawValue: "ml"),
                presentationKind: .solution,
                refType: "act",
                refNameLatNom: "Sol. Natrii bromidi 2%"
            ),
            IngredientDraft(
                displayName: "Sol. Magnesii sulfatis 20%",
                role: .active,
                amountValue: 50,
                unit: UnitCode(rawValue: "ml"),
                presentationKind: .solution,
                refType: "act",
                refNameLatNom: "Sol. Magnesii sulfatis 20%"
            )
        ]

        return RxFixtureScenario(
            id: "multiple_solution_ingredients",
            title: "Normalizer keeps multiple solution ingredients untouched",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, WaterSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Склад"],
            validator: { evaluated in
                var errors: [String] = []
                let solutionCount = evaluated.normalizedDraft.ingredients.filter { $0.presentationKind == .solution }.count
                if solutionCount < 2 {
                    errors.append("normalizer changed solution presentation kinds; expected >=2, got \(solutionCount)")
                }
                let hasExpectedWarning = evaluated.issues.contains {
                    $0.code == "sol.multiple"
                        && $0.message == "У рецепті кілька Sol.-компонентів; нормалізатор не повинен змінювати їх presentationKind"
                }
                if !hasExpectedWarning {
                    errors.append("missing warning sol.multiple with updated message")
                }
                return errors
            }
        )
    }

    private static func buretteMassDerivationFailureScenario() -> RxFixtureScenario {
        var d = ExtempRecipeDraft()
        d.formMode = .solutions
        d.liquidTechnologyMode = .waterSolution
        d.useBuretteSystem = true
        d.targetValue = 100
        d.targetUnit = UnitCode(rawValue: "ml")
        d.signa = "По 1 столовой ложке 3 раза в день"
        d.ingredients = [
            IngredientDraft(
                displayName: "Natrii bromidum",
                role: .active,
                amountValue: 10,
                unit: UnitCode(rawValue: "ml"),
                presentationKind: .substance,
                refType: "act",
                refNameLatNom: "Natrii bromidum"
            )
        ]

        return RxFixtureScenario(
            id: "burette_mass_derivation_failure",
            title: "Burette mode reports blocking issue when solute mass cannot be derived",
            draft: d,
            expectedActivatedBlocks: [BaseTechnologyBlock.blockId, BuretteSystemBlock.blockId, WaterSolutionsBlock.blockId],
            forbiddenActivatedBlocks: [],
            expectedSectionTitles: ["Розрахунки"],
            forbiddenLineFragments: [
                "Раствор натрия бромида 20%: V_conc = 0"
            ],
            validator: { evaluated in
                var errors: [String] = []
                let hasBlocking = evaluated.issues.contains {
                    $0.code == "burette.mass_derivation_failed" && $0.severity == .blocking
                }
                if !hasBlocking {
                    errors.append("missing blocking issue burette.mass_derivation_failed")
                }
                let renderedLines = evaluated.derived.ppkSections.flatMap(\.lines).joined(separator: "\n")
                if renderedLines.contains("Раствор натрия бромида 20%: V_conc") {
                    errors.append("invalid burette line rendered despite mass derivation failure")
                }
                return errors
            }
        )
    }
}
