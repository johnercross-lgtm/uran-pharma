import Foundation

struct AdCalculationResult {
    let targetVolume: Double
    let componentsVolume: Double
    let solidsWeight: Double
    let displacementVolume: Double
    let amountToMeasure: Double
    let rawAmountToMeasure: Double
    let isImpossible: Bool
    let needsKuo: Bool
    let missingKuoCount: Int
}

enum PharmaCalculator {
    static func calculateAdWater(
        targetVolume: Double,
        otherLiquids: [Double],
        solids: [(weight: Double, kuo: Double?)]
    ) -> AdCalculationResult {
        let normalizedTarget = max(0, targetVolume)
        let sumLiquids = otherLiquids.reduce(0.0) { $0 + max(0, $1) }

        let normalizedSolids = solids.map { (weight: max(0, $0.weight), kuo: $0.kuo) }
        let totalSolidsWeight = normalizedSolids.reduce(0.0) { $0 + $1.weight }

        let solidsPercentage = normalizedTarget > 0
            ? (totalSolidsWeight / normalizedTarget) * 100.0
            : 0.0
        let potentialDisplacement = normalizedSolids.reduce(0.0) { partial, solid in
            guard let kuo = solid.kuo, kuo > 0 else { return partial }
            return partial + (solid.weight * kuo)
        }
        let displacementPercent = normalizedTarget > 0
            ? (potentialDisplacement / normalizedTarget) * 100.0
            : 0.0
        let needsKuo = solidsPercentage >= 3.0 || displacementPercent >= 3.0

        var displacement = 0.0
        var missingKuoCount = 0

        if needsKuo {
            for solid in normalizedSolids where solid.weight > 0 {
                guard let kuo = solid.kuo, kuo > 0 else {
                    missingKuoCount += 1
                    continue
                }
                displacement += solid.weight * kuo
            }
        }

        let rawToMeasure = normalizedTarget - sumLiquids - displacement

        return AdCalculationResult(
            targetVolume: normalizedTarget,
            componentsVolume: sumLiquids,
            solidsWeight: totalSolidsWeight,
            displacementVolume: displacement,
            amountToMeasure: max(0, rawToMeasure),
            rawAmountToMeasure: rawToMeasure,
            isImpossible: rawToMeasure <= 0,
            needsKuo: needsKuo,
            missingKuoCount: missingKuoCount
        )
    }
}
